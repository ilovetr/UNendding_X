"""WebSocket package."""
